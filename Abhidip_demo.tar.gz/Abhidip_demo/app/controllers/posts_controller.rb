class PostsController < ApplicationController
end
